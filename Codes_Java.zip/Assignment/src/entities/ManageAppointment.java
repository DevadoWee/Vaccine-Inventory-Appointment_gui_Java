/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author David
 */
import java.io.BufferedReader;
import java.util.Scanner;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileWriter;
import java.util.Arrays;
import java.util.stream.Collectors;

public class ManageAppointment {
    private String line;
    private String[] appointment_content;
    
    public String[] GetAllAppointment(){
        try  {
            //To know which line the People is at.
            File AppointmentFile = new File("src/txt/appointmentdata.txt");
            FileReader fr = new FileReader(AppointmentFile);
            BufferedReader br = new BufferedReader(fr);
            appointment_content = new String[150];
            int index = 0;

            while((line=br.readLine()) != null) {
                appointment_content[index] = line;
                index += 1;
            }
            fr.close();
            
        } catch (IOException e) {
            
            System.out.println("An Error has occured\n");
        }
        return appointment_content;
    }
    
    public String[] SearchAppointment(int col_num, String item){
        try  {
            //To know which line the people is at.
            File AppointmentFile = new File("src/txt/appointmentdata.txt");
            FileReader fr = new FileReader(AppointmentFile);
            BufferedReader br = new BufferedReader(fr);

            appointment_content = new String[150];
            int index = 0;

            while((line=br.readLine()) != null) {
                //people_content[index] = line;
                String[] brokenLine = line.split("\t");     

                //find same codes then take the line.
                //break the line, change it, and join it
                //addition happens here
                if(item.equals(brokenLine[col_num]) == true) {
                   appointment_content[index] = line;
                   index += 1;
                }
            }
            
            fr.close();
            return (appointment_content);

        } catch (IOException e) {

            System.out.println("An Error has occured\n");
            return(appointment_content);
        }
    }
        
    //
    public boolean VerifyAppointmentDupplication(int col_num, String item){
        try  {
            //To know which line the people is at.
            File AppointmentFile = new File("src/txt/appointmentdata.txt");
            FileReader fr = new FileReader(AppointmentFile);
            BufferedReader br = new BufferedReader(fr);


            while((line=br.readLine()) != null) {
                //people_content[index] = line;
                String[] brokenLine = line.split("\t");     

                //find same codes then take the line.
                //break the line, change it, and join it
                //addition happens here
                if(item.equals(brokenLine[col_num]) == true && brokenLine[5].equals("NA")) {
                   fr.close();
                   return true;
                }
            }
            
            fr.close();
            return false;

        } catch (IOException e) {

            System.out.println("An Error has occured\n");
            return false;
        }
    }   
        
    public boolean AddAppointment(String ID) {
        peopleLogin PL = new peopleLogin();
        String[] people_content;
        people_content = new String[15];
        people_content = PL.findLine(ID);
        String[] line_content;
        line_content = new String[15];
        String[] line_add;
        line_add = new String[15];
        int date = 6;
        int count = 0;
        boolean found;
        ManagePeople MP = new ManagePeople();
        line_add = MP.SearchPeople(0, ID);
        
        if (line_add[0] == null){
            return false;
        }
        System.out.println("we");
        line_add = line_add[0].split("\t");
        if (line_add[4].equals("Vaccinated")){
            return false;
        }
        
        if (people_content[0] == null){
            return false;
        }
        
        //Verify if theres duplicate in appointment
        found = VerifyAppointmentDupplication(1,ID);
        if (found == true){
            return false;
        }  
        
        //Verify if Vaccination is done on people
        try {
            
            //count for appointment_ID
            File filecount = new File("src/txt/appointmentdata.txt");
               Scanner Sc = new Scanner(filecount);
               while(Sc.hasNextLine()) {
                   line = Sc.nextLine();
               }
               Sc.close();
               
               //take last ID and + 1.
               line_content = line.split("\t");
               count = Integer.valueOf(line_content[0]) + 1;
               
               //decide its dose 1 or 2. or if people not yet signed up for appointment.
            if (people_content[6].equals("NA")){
                return false;
            }else if (people_content[7].equals("Done")){
                date = 8;
            }else if (people_content[9].equals("Done")){
                return false;
            }    
            
            
            FileWriter AppointmentFile = new FileWriter("src/txt/appointmentdata.txt", true);
            AppointmentFile.write(count + "\t" + people_content[0] + "\t" + people_content[10] + "\t" 
                    + people_content[5] + "\t" + people_content[date] + "\t" + "NA" +"\n");
            AppointmentFile.close();
            
            
            
            if (date == 6){
                MP.ModifyPeople(people_content[0], people_content[1], people_content[2], people_content[3], 
                    people_content[4], people_content[5], people_content[6], "Approved", 
                    people_content[8], people_content[9], people_content[10], people_content[11], people_content[12]);
            }else if (date == 8){
                MP.ModifyPeople(people_content[0], people_content[1], people_content[2], people_content[3], 
                        people_content[4], people_content[5], people_content[6], people_content[7], 
                        people_content[8], "Approved", people_content[10], people_content[11], people_content[12]);
            }
            return true;
            
        }catch(IOException e){
            System.out.println("An Error has occured\n");
            return false;
        }
    }
    
    
    public int FindLineNum(String ID){

        try  {
            
            File AppointmentFile = new File("src/txt/appointmentdata.txt");
            FileReader fr = new FileReader(AppointmentFile);
            BufferedReader br = new BufferedReader(fr);
            appointment_content = new String[15];
            int index = 0;
            
            while((line=br.readLine()) != null) {
                appointment_content = line.split("\t");
                
                if(ID.equals(appointment_content[0]) == true) {
                   
                    fr.close();
                    return index;
                    
                }
                index++;
            }
            fr.close();
            return -1;
            
        } catch (IOException e) {
            
            System.out.println("An Error has occured");
            
            e.printStackTrace();
            return -1;
        }
        
    }
    
    
    public boolean RemoveAppointment(String ID){
        try  {
            int line_count = 0;
            line_count = FindLineNum(ID);
            //To know which line the people is at.
            File AppointmentFile = new File("src/txt/appointmentdata.txt");
            FileReader fr = new FileReader(AppointmentFile);
            BufferedReader br = new BufferedReader(fr);
            appointment_content = new String[150];
            String[] line_content;
            int index = 0;
            String later_line;
            while((line=br.readLine()) != null) {
                appointment_content[index] = line;
                index += 1;
            }
            fr.close();
            if (line_count == -1){
                return false;
            }
            later_line = appointment_content[line_count];
            
            if (line_count >= 0){
                FileWriter fw = new FileWriter("src/txt/appointmentdata.txt",false);
                for (int i = 0; i < index; i++ ){
                    //if line is up to line_count, we can remove it.
                    // along with re-writing the whole file.
                   if (i == line_count){
                       ;
                   }else{
                       fw.write(appointment_content[i]+"\n");
                   }
                }
                fw.close();
                

                // SECOND PHASE SECOND PHASE SECOND PHASE
                //line_content is actually array for patient line.
                line_content = new String [15];
                line_content = later_line.split("\t");
                peopleLogin PL = new peopleLogin();
                line_content = PL.findLine(line_content[1]);
                ManagePeople MP = new ManagePeople();
                
                if (line_content[9].equals("Approved") || line_content[9].equals("Done")){
                    MP.ModifyPeople(line_content[0], line_content[1], line_content[2], line_content[3],
                            line_content[4], line_content[5], line_content[6], line_content[7],
                            line_content[8], "Not Done", line_content[10], 
                            line_content[11], line_content[12]);
                }else if (line_content[7].equals("Approved") ||  line_content[7].equals("Done")){
                    MP.ModifyPeople(line_content[0], line_content[1], line_content[2], line_content[3],
                            line_content[4], line_content[5], line_content[6], "Not Done",
                            line_content[8], line_content[9], line_content[10], 
                            line_content[11], line_content[12]);
                }
               
                return true;

            } else{
                System.out.println("Appointment not found.\nPlease Try Again.\n");
                return false;
            }
            
        } catch (IOException e) {
            
            System.out.println("An Error has occured.\n");
            return false;
        } 
    }
    
    public boolean ModifyAppointment(String ID, String Progress){
        try  {
            int line_count = 0;
            line_count = FindLineNum(ID);
            //To know which line the people is at.
            File AppointmentFile = new File("src/txt/appointmentdata.txt");
            FileReader fr = new FileReader(AppointmentFile);
            BufferedReader br = new BufferedReader(fr);
            appointment_content = new String[150];
            String[] line_content;
            line_content = new String [15];
            int index = 0;
            String later_line;
            
            while((line=br.readLine()) != null) {
                appointment_content[index] = line;
                index += 1;
            }
            fr.close();
            
            if (line_count == -1){
                return false;
            }
            
            later_line = appointment_content[line_count];
            if (line_count >= 0){
                FileWriter fw = new FileWriter("src/txt/appointmentdata.txt",false);
                for (int i = 0; i < index; i++ ){
                    //if line is up to line_count, we can replace it with what we want.
                    // along with re-writing the whole file.
                   if (i == line_count){

                       if (Progress.equals("Completed")){
                            line_content = later_line.split("\t");
                            line_content[5] = "Completed";
                            appointment_content[i] = String.join("\t",line_content);
                            fw.write(appointment_content[i]+"\n"); 
                            
                       }else if(Progress.equals("NA")){
                            line_content = later_line.split("\t");
                            line_content[5] = "NA";
                            appointment_content[i] = Arrays.stream(line_content).collect(Collectors.joining("\t"));
                            fw.write(appointment_content[i]+"\n");
                       }
                       
                   }else{
                       fw.write(appointment_content[i]+"\n");
                   }
                }
                fw.close();

                // SECOND PHASE SECOND PHASE SECOND PHASE
                //line_content is actually array for patient line.
                line_content = new String [15];
                line_content = later_line.split("\t");
                peopleLogin PL = new peopleLogin();
                line_content = PL.findLine(line_content[1]);
                ManagePeople MP = new ManagePeople();

                if (Progress.equals("Completed")){
                    if (line_content[9].equals("Approved")){
                    MP.ModifyPeople(line_content[0], line_content[1], line_content[2], line_content[3],
                            "Vaccinated", line_content[5], line_content[6], line_content[7],
                            line_content[8], "Done", line_content[10], 
                            line_content[11], line_content[12]);
                }else if (line_content[7].equals("Approved")){
                    MP.ModifyPeople(line_content[0], line_content[1], line_content[2], line_content[3],
                            line_content[4], line_content[5], line_content[6], "Done",
                            line_content[8], line_content[9], line_content[10], 
                            line_content[11], line_content[12]);
                }
                    
                }else if (Progress.equals("NA")){
                    if (line_content[9].equals("Done")){
                    MP.ModifyPeople(line_content[0], line_content[1], line_content[2], line_content[3],
                            "Not Vaccinated", line_content[5], line_content[6], line_content[7],
                            line_content[8], "Approved", line_content[10], 
                            line_content[11], line_content[12]);
                }else if (line_content[7].equals("Done")){
                    MP.ModifyPeople(line_content[0], line_content[1], line_content[2], line_content[3],
                            line_content[4], line_content[5], line_content[6], "Approved",
                            line_content[8], line_content[9], line_content[10], 
                            line_content[11], line_content[12]);
                }
                }
               
                return true;

            } else{
                System.out.println("Appointment not found.\nPlease Try Again.\n");
                return false;
            }
            
        } catch (IOException e) {
            
            System.out.println("An Error has occured.\n");
            return false;
        } 
    }
}
