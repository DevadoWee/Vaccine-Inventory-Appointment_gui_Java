/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author David
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileWriter;
import java.util.Arrays;
import java.util.stream.Collectors;


public class ManageVaccine {
    // index just to count the lines.
    // line_count to keep no. of specific line.
    private int index = 0;
    private int line_count;
    private String[] old_content;
    private String line;
    private String new_line;
            
    public boolean AddVaccine(String CentreCode, String VacCode ,int VacQuantity){
        try  {
            //To know which line the vaccine is at.
            File VaccineFile = new File("src/txt/centredata.txt");
            FileReader fr = new FileReader(VaccineFile);
            BufferedReader br = new BufferedReader(fr);
            int quantity;
            old_content = new String[100];
            new_line = "empty";
            int found = 0;

            while((line=br.readLine()) != null) {
                old_content[index] = line;
                String[] brokenLine = line.split("\t");     

                //find same codes then take the line.
                //break the line, change it, and join it
                //addition happens here
                if(CentreCode.equals(brokenLine[0]) == true && VacCode.equals(brokenLine[2]) == true) {
                   quantity = Integer.parseInt(brokenLine[3]);
                   quantity += VacQuantity;
                   brokenLine[3] = Integer.toString(quantity);
                   new_line = Arrays.stream(brokenLine).collect(Collectors.joining("\t"));
                   line_count = index; //empty line 
                   found += 1;
                }
                
                index += 1;
            }
            fr.close();
            
            if (found == 1){
                FileWriter fw = new FileWriter("src/txt/centredata.txt",false);
                for (int i = 0; i < index; i++ ){
                    //if line is up to line_count, we can replace it with what we want.
                    // along with re-writing the whole file.
                   if (i == line_count){
                       fw.write(new_line + "\n");
                   }else{
                       fw.write(old_content[i]+"\n");
                   }
                }
                fw.close();
                return true;
                
            } else{
                System.out.println("Vaccine not found.\nPlease Try Again.\n");
                return false;
            }
            
        } catch (IOException e) {
            
            System.out.println("An Error has occured\n");
            return false;
        } 
    }
    
    
    public boolean RemoveVaccine(String CentreCode, String VacCode ,int VacQuantity){
        try  {
            //To know which line the vaccine is at.
            File VaccineFile = new File("src/txt/centredata.txt");
            FileReader fr = new FileReader(VaccineFile);
            BufferedReader br = new BufferedReader(fr);
            int quantity;
            old_content = new String[100];
            new_line = "empty";
            int found = 0;

            while((line=br.readLine()) != null) {
                old_content[index] = line;
                String[] brokenLine = line.split("\t");     

                //find same codes then take the line.
                //break the line, change it, and join it
                //deduct happens here
                if(CentreCode.equals(brokenLine[0]) == true && VacCode.equals(brokenLine[2]) == true) {
                   quantity = Integer.parseInt(brokenLine[3]);
                   quantity -= VacQuantity;
                   brokenLine[3] = Integer.toString(quantity);
                   new_line = Arrays.stream(brokenLine).collect(Collectors.joining("\t"));
                   line_count = index; //empty line 
                   found += 1;
                }
                
                index += 1;
            }
            fr.close();
            
            if (found == 1){
                FileWriter fw = new FileWriter("src/txt/centredata.txt",false);
                for (int i = 0; i < index; i++ ){
                    //if line is up to line_count, we can replace it with what we want.
                    // along with re-writing the whole file.
                   if (i == line_count){
                       fw.write(new_line + "\n");
                   }else{
                       fw.write(old_content[i]+"\n");
                   }
                }
                fw.close();
                return true;
                
            } else{
                System.out.println("Vaccine not found.\nPlease Try Again.\n");
                return false;
            }
            
        } catch (IOException e) {
            
            System.out.println("An Error has occured\n");
            return false;
        } 
    }
    
    //Directly change vaccine quantity
    public boolean ModifyVaccine(String CentreCode, String VacCode ,int VacQuantity){
        try  {
            //To know which line the vaccine is at.
            File VaccineFile = new File("src/txt/centredata.txt");
            FileReader fr = new FileReader(VaccineFile);
            BufferedReader br = new BufferedReader(fr);
            int quantity;
            old_content = new String[100];
            new_line = "empty";
            int found = 0;

            while((line=br.readLine()) != null) {
                old_content[index] = line;
                String[] brokenLine = line.split("\t");     

                //find same codes then take the line.
                //break the line, change it, and join it
                //deduct happens here
                if(CentreCode.equals(brokenLine[0]) == true && VacCode.equals(brokenLine[2]) == true) {
                   quantity = Integer.parseInt(brokenLine[3]);
                   quantity = VacQuantity;
                   brokenLine[3] = Integer.toString(quantity);
                   new_line = Arrays.stream(brokenLine).collect(Collectors.joining("\t"));
                   line_count = index; //empty line 
                   found += 1;
                }
                
                index += 1;
            }
            fr.close();
            
            if (found == 1){
                FileWriter fw = new FileWriter("src/txt/centredata.txt",false);
                for (int i = 0; i < index; i++ ){
                    //if line is up to line_count, we can replace it with what we want.
                    // along with re-writing the whole file.
                   if (i == line_count){
                       fw.write(new_line + "\n");
                   }else{
                       fw.write(old_content[i]+"\n");
                   }
                }
                fw.close();
                return true;
            } else{
                System.out.println("Vaccine not found.\nPlease Try Again.\n");
                return false;
            }
            
        } catch (IOException e) {
            
            System.out.println("An Error has occured.\n");
            return false;
        } 
    }
    
    
    public void ViewVaccine(){
        
        try{
            File VaccineFile = new File("src/txt/centredata.txt");
            FileReader fr = new FileReader(VaccineFile);
            BufferedReader br = new BufferedReader(fr);
            System.out.format("%-11s\t%-21s\t%-8s\t%-10s\n","Location ID","Location","Vac Code","Quantity");

            //Just attempting to displaying it more Visual-loving.
            while((line=br.readLine()) != null){
                String[] brokenLine = line.split("\t");

                for (int i = 0; i < brokenLine.length; i++){
                    switch (i){
                        case 0 :
                            System.out.format("%-11s\t",brokenLine[i]);
                            break;
                            
                        case 1 :
                            System.out.format("%-21s\t",brokenLine[i]);
                            break;
                            
                        case 2 :
                            System.out.format("%-8s\t",brokenLine[i]);
                            break;
                            
                        case 3 :
                            System.out.format("%-10s\n",brokenLine[i]);
                            break;
                    }
                }
            }
            System.out.println("\n");
                
        }catch (IOException e){
            System.out.println("An Error has occured.\n");
        }
    }
    
    //just displays vaccines groupby centre
    public boolean SearchVaccine(String Centrecode){
        try{
            File VaccineFile = new File("src/txt/centredata.txt");
            FileReader fr = new FileReader(VaccineFile);
            BufferedReader br = new BufferedReader(fr);
            System.out.format("%-11s\t%-21s\t%-8s\t%-10s\n","Location ID","Location","Vac Code","Quantity");
            int found = 0;
                    
            //Just attempting to displaying it more Visual-loving.
            while((line=br.readLine()) != null){
                String[] brokenLine = line.split("\t");
                if (Centrecode.equals(brokenLine[0])){
                    found += 1;
                    for (int i = 0; i < brokenLine.length; i++){
                        switch (i){
                            case 0 :
                                System.out.format("%-11s\t",brokenLine[i]);
                                break;

                            case 1 :
                                System.out.format("%-21s\t",brokenLine[i]);
                                break;

                            case 2 :
                                System.out.format("%-8s\t",brokenLine[i]);
                                break;

                            case 3 :
                                System.out.format("%-10s\n",brokenLine[i]);
                                break;
                        }
                    }
                }
            }
            System.out.println("\n");
            if (found == 0){
                System.out.println("Centre not found, please try again.\n");
                return false;
            }
            return true;
                
        }catch (IOException e){
            System.out.println("An Error has occured.\n");
            return true;
        }
    }
}
