/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author David
 */
import java.io.BufferedReader;
import java.util.Scanner;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileWriter;


public class ManagePeople {
    private String line;
    private String[] people_content;
    
    public String[] GetAllPeople(){
        try  {
            //To know which line the People is at.
            File PatientFile = new File("src/txt/patientdata.txt");
            FileReader fr = new FileReader(PatientFile);
            BufferedReader br = new BufferedReader(fr);
            people_content = new String[150];
            int index = 0;

            while((line=br.readLine()) != null) {
                people_content[index] = line;
                index += 1;
            }
            fr.close();
            
        } catch (IOException e) {
            
            System.out.println("An Error has occured\n");
        }
        return people_content;
    }

    
    
    public String[] SearchPeople(int col_num, String item){
        try  {
            //To know which line the people is at.
            File PatientFile = new File("src/txt/patientdata.txt");
            FileReader fr = new FileReader(PatientFile);
            BufferedReader br = new BufferedReader(fr);

            people_content = new String[150];
            int index = 0;

            while((line=br.readLine()) != null) {
                //people_content[index] = line;
                String[] brokenLine = line.split("\t");     

                //find same codes then take the line.
                //break the line, change it, and join it
                //addition happens here
                if(item.equals(brokenLine[col_num]) == true) {
                   people_content[index] = line;
                   index += 1;
                }
            }
            
            fr.close();
            return (people_content);

        } catch (IOException e) {

            System.out.println("An Error has occured\n");
            return(people_content);
        } 
    }
    
    public void RegisterPeople(String Citizenship,String Name,String age,
            String status,String Vac_Name,String F1_Date,String F1_Status,
            String F2_Date,String F2_Status,String Vac_Location,
            String Username,String Password){
        int count = 0;
        
        try {
            
            // To check how many lines in file so can calculate next patient ID
           File filecount = new File("src/txt/patientdata.txt");
           Scanner Sc = new Scanner(filecount);
           while(Sc.hasNextLine()) {
               Sc.nextLine();
               count++;
           }
           Sc.close();

           count += 1001;
            
           FileWriter patientfile = new FileWriter("src/txt/patientdata.txt", true);
           
           patientfile.write(count + "\t" + Citizenship + "\t" + Name + "\t" + age + "\t" + status 
                   + "\t" + Vac_Name + "\t" + F1_Date + "\t" + F1_Status + "\t" + F2_Date + "\t" + 
                   F2_Status + "\t" + Vac_Location + "\t" + Username + "\t" + Password + "\n");
           
           
           patientfile.close();
           
           System.out.println("Successfully Registered");
           
        } catch (IOException e) {
            
            System.out.println("An Error has occured");
            
            e.printStackTrace();
        }
    }
    
    
    public boolean ModifyPeople(String ID,String Citizenship,String Name,String age,
            String status,String Vac_Name,String F1_Date,String F1_Status,
            String F2_Date,String F2_Status,String Vac_Location,
            String Username,String Password){
        try  {
            //To know which line the people is at.
            File PeopleFile = new File("src/txt/patientdata.txt");
            FileReader fr = new FileReader(PeopleFile);
            BufferedReader br = new BufferedReader(fr);
            int quantity;
            people_content = new String[150];
            int found = 0;
            int index = 0;
            int line_count = 0;
            String new_line = null;

            while((line=br.readLine()) != null) {
                people_content[index] = line;
                String[] brokenLine = line.split("\t");     

                //find same codes then take the line.
                //break the line, change it, and join it
                //deduct happens here
                if(ID.equals(brokenLine[0]) == true) {
                   new_line = ID + "\t" + Citizenship + "\t" + Name + "\t" + age + "\t" + status
                           + "\t" + Vac_Name + "\t" + F1_Date + "\t" + F1_Status + "\t" + F2_Date + "\t" +
                           F2_Status + "\t" + Vac_Location + "\t" + Username + "\t" + Password;
                   line_count = index; 
                   found += 1;
                }
                
                index += 1;
            }
            fr.close();
            
            if (found == 1){
                FileWriter fw = new FileWriter("src/txt/patientdata.txt",false);
                for (int i = 0; i < index; i++ ){
                    //if line is up to line_count, we can replace it with what we want.
                    // along with re-writing the whole file.
                   if (i == line_count){
                       fw.write(new_line + "\n");
                   }else{
                       fw.write(people_content[i]+"\n");
                   }
                }
                fw.close();
                return true;
            } else{
                System.out.println("People not found.\nPlease Try Again.\n");
                return false;
            }
            
        } catch (IOException e) {
            
            System.out.println("An Error has occured.\n");
            return false;
        } 
    }
}
