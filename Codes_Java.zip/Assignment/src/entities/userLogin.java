/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author user
 */
public class userLogin {
   
    
    private String username, password;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public boolean verify(String username, String password) {
        
        return false;        
    }
    
    public void loginActivity(String username) {
        
        try {
            
            
           FileWriter loginfile = new FileWriter("src/txt/loginactivity.txt", true);
           
           Date date = new Date();
           SimpleDateFormat dmy = new SimpleDateFormat("dd/MM/yy");
           SimpleDateFormat time = new SimpleDateFormat("HH:mm");
           String currentDate = dmy.format(date);
           String currentTime = time.format(date);
           
           loginfile.write(currentDate + "\t" + currentTime + "\t" + username + "\n");
           
           loginfile.close();
           
        } catch (IOException e) {
            System.out.println("An Error has occured");
            e.printStackTrace();
        }
        
    }
    

    
}
