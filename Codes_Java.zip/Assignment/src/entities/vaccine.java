 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author user
 */
public class vaccine {

    public vaccine() {
    }
    
    private String vacID, vacName, vacDos, vacNA;

    public String getVacNA() {
        return vacNA;
    }

    public void setVacNA(String vacNA) {
        this.vacNA = vacNA;
    }

    public String getVacID() {
        return vacID;
    }

    public void setVacID(String vacID) {
        this.vacID = vacID;
    }

    public String getVacName() {
        return vacName;
    }

    public void setVacName(String vacName) {
        this.vacName = vacName;
    }

    public String getVacDos() {
        return vacDos;
    }

    public void setVacDos(String vacDos) {
        this.vacDos = vacDos;
    }

    
    
    public void addVaccine(String vacID, String vacName, String vacDos) {
        
        
        try {
            
           FileWriter vaccinefile = new FileWriter("src/txt/vaccinedata.txt", true);
           

           vaccinefile.write(vacID + "\t" + vacName + "\t" + vacDos  + "\n");
           
           
           vaccinefile.close();
           
           System.out.println("Successfully Registered");
           
        } catch (IOException e) {
            
            System.out.println("An Error has occured");
            
            e.printStackTrace();
        }
    }
    
    
    public String getVaccine(String vacID) {
        
        try  {
            
            File vaccinefile = new File("src/txt/vaccinedata.txt");
            FileReader fr = new FileReader(vaccinefile);
            BufferedReader br = new BufferedReader(fr);
            String line;
            
            while((line=br.readLine()) != null) {
                
                
                String[] brokenLine = line.split("\t");
             
                if(vacID.equals(brokenLine[0]) == true) {
                    
                    String vaccineIDo = brokenLine[1];
                    
                    return vaccineIDo;
                }
            }
            fr.close();
            
        } catch (IOException e) {
            
            System.out.println("An Error has occured");
            
            e.printStackTrace();
        }
        
        return "forgot";
    }
    
    
    public int getDosage(String vacID) {
        
        try  {
            
            File vaccinefile = new File("src/txt/vaccinedata.txt");
            FileReader fr = new FileReader(vaccinefile);
            BufferedReader br = new BufferedReader(fr);
            String line;
            
            while((line=br.readLine()) != null) {
                
                
                String[] brokenLine = line.split("\t");
             
                if(vacID.equals(brokenLine[0]) == true) {
                    
                    int vacDosage = Integer.parseInt(brokenLine[2]);
                    
                    
                    
                    return vacDosage;
                }
            }
            fr.close();
            
        } catch (IOException e) {
            
            System.out.println("An Error has occured");
            
            e.printStackTrace();
        }
        
        return 0;
    }
    
    public int getDosFromName(String vacName1) {
        
        try  {
            
            File vaccinefile = new File("src/txt/vaccinedata.txt");
            FileReader fr = new FileReader(vaccinefile);
            BufferedReader br = new BufferedReader(fr);
            String line;
            
            while((line=br.readLine()) != null) {
                
                
                String[] brokenLine = line.split("\t");
             
                if(vacName1.equals(brokenLine[1]) == true) {
                    
                    int vacDosage = Integer.parseInt(brokenLine[2]);
                    
                    return vacDosage;
                }
            }
            fr.close();
            
        } catch (IOException e) {
            
            System.out.println("An Error has occured");
            
            e.printStackTrace();
        }
        
        return 0;
    }
        
        
        
    
    
    
    
    


    
    
    
    
    
    
    
    
    
    
}
