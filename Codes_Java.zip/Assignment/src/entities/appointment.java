/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class appointment extends centre{
    
    private String firstDoseApp, firstDoseStat, secondDoseApp, secondDoseStat;

    public appointment() {
    }

    public String getFirstDoseApp() {
        return firstDoseApp;
    }

    public void setFirstDoseApp(String firstDoseApp) {
        this.firstDoseApp = firstDoseApp;
    }

    public String getFirstDoseStat() {
        return firstDoseStat;
    }

    public void setFirstDoseStat(String firstDoseStat) {
        this.firstDoseStat = firstDoseStat;
    }

    public String getSecondDoseApp() {
        return secondDoseApp;
    }

    public void setSecondDoseApp(String secondDoseApp) {
        this.secondDoseApp = secondDoseApp;
    }

    public String getSecondDoseStat() {
        return secondDoseStat;
    }

    public void setSecondDoseStat(String secondDoseStat) {
        this.secondDoseStat = secondDoseStat;
    }
    
    
    public void bookAppointment(String[] patientRec, String date) {
        
        int count = 0;
        
        try {
            
            // To check how many lines in file so can calculate next appointment ID
           File filecount = new File("src/txt/appointmentdata.txt");
           Scanner Sc = new Scanner(filecount);
           while(Sc.hasNextLine()) {
               Sc.nextLine();
               count++;
           }
           Sc.close();

           count += 1001;
            
           FileWriter appointmentfile = new FileWriter("src/txt/appointmentdata.txt", true);
           
           appointmentfile.write(count + "\t" + "P" + patientRec[0] + "\t" +  patientRec[10] + "\t" + patientRec[5] + "\t" + date + "\n");
           
           appointmentfile.close();
           
           System.out.println("Successfully booked");
           
        } catch (IOException e) {
            
            System.out.println("An Error has occured");
            
            e.printStackTrace();
        }
    }
    
    public void setAppointmentDates(int AppNum, String[] Fullline, String appDate) {
        
        try  {
            
            File patientfile = new File("src/txt/patientdata.txt");
            FileReader fr = new FileReader(patientfile);
            BufferedReader br = new BufferedReader(fr);
            String line;
            
            StringBuilder newFileContents = new StringBuilder();
            
            
            while((line=br.readLine()) != null) {
                
                
                String[] brokenLine = line.split("\t");
             
                if(Fullline[0].equals(brokenLine[0]) == true) {
                    
                    if(AppNum == 1) {
                    
                    String newLine = Fullline[0] + "\t" + Fullline[1] + "\t" + Fullline[2] + "\t" + Fullline[3] + "\t" + Fullline[4] + "\t" + Fullline[5] + "\t" + appDate
                            + "\t" + Fullline[7] + "\t" + Fullline[8] + "\t" + Fullline[9] + "\t" + Fullline[10] + "\t" + Fullline[11] + "\t" + Fullline[12];
                    
                    newFileContents.append(newLine);
                    newFileContents.append("\n");
                    
                    
                    System.out.println(newLine);
                    
                    } else {
                        
                        String newLine = Fullline[0] + "\t" + Fullline[1] + "\t" + Fullline[2] + "\t" + Fullline[3] + "\t" + Fullline[4] + "\t" + Fullline[5] + "\t" + Fullline[6]
                            + "\t" + Fullline[7] + "\t" + appDate + "\t" + Fullline[9] + "\t" + Fullline[10] + "\t" + Fullline[11] + "\t" + Fullline[12];
                    
                        newFileContents.append(newLine);
                        newFileContents.append("\n");
                    
                    
                        System.out.println(newLine);
                        
                        
                    }
                    
                } else {
                    
                    newFileContents.append(line);
                    newFileContents.append("\n");
                    
                }
                
                
            }
            
            
            fr.close();
            
            FileWriter newPatientFile = new FileWriter("src/txt/patientdata.txt");
            BufferedWriter output = new BufferedWriter(newPatientFile);
            
            System.out.println(newFileContents);
            

            
            output.write(newFileContents.toString());
            
            output.close();
            
            
            
        } catch (IOException e) {
            
            System.out.println("An Error has occured");
            
            e.printStackTrace();
        }
        
        
        
    }
    
    
    
    
    
    
    
}
