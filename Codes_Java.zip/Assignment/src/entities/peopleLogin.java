/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author user
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.util.Scanner;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileWriter;
import java.io.PrintWriter;



public class peopleLogin extends userLogin {
    
    private String fullName, Citizenship, age, patientID, restData, vacStatus, vacname;
    private String[] patientRec;
    
    public String getVacname() {
        return vacname;
    }

    public void setVacname(String vacname) {
        this.vacname = vacname;
    }
    
    
    
    public String getVacStatus() {
        return vacStatus;
    }

    public void setVacStatus(String vacStatus) {
        this.vacStatus = vacStatus;
    }
    

    public String[] getPatientRec() {
        return patientRec;
    }

    public void setPatientRec(String[] patientRec) {
        this.patientRec = patientRec;
    }

    public String getRestData() {
        return restData;
    }

    public void setRestData(String vacStat, String vacName, String Fdate, String FStatus, String Sdate, String SStatus, String vacLoc) {
        this.restData = vacStat + "\t" + vacName + "\t" + Fdate + "\t" + FStatus + "\t" + Sdate + "\t" + SStatus + "\t" + vacLoc;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String firstName, String lastName) {
        this.fullName = firstName + " " + lastName;
    }
    
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    
    public String getCitizenship() {
        return Citizenship;
    }

    public void setCitizenship(String Citizenship) {
        this.Citizenship = Citizenship;
    }

    public String getAge() {
        return age;
    }
    
    public int getIntAge() {
        
        return Integer.parseInt(age);
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getPatientID() {
        return patientID;
    }

    public void setPatientID(String patientID) {
        this.patientID = patientID;
    }
    
    
    
    
    
    public peopleLogin() {
        
        
    }
    
    public void openPatientFile(String fileName) {
        
        try {
           File patientfile = new File(fileName);
           if(patientfile.createNewFile()) {
               System.out.println("File Created: " + patientfile.getName());
           } else {
              System.out.println("File Already exists.");

              
           }
        } catch (IOException e) {
            System.out.println("An Error has occured");
            e.printStackTrace();
        }
        
        
        
    }
    
    public void register(String fullName, String age, String citizenship, String username, String password) {
        
        

        int count = 0;
        

        try {
            
            // To check how many lines in file so can calculate next patient ID
           File filecount = new File("src/txt/patientdata.txt");
           Scanner Sc = new Scanner(filecount);
           while(Sc.hasNextLine()) {
               Sc.nextLine();
               count++;
           }
           Sc.close();

           count += 1001;
            
           FileWriter patientfile = new FileWriter("src/txt/patientdata.txt", true);
           
           patientfile.write(count + "\t" + citizenship + "\t" + fullName + "\t" + age + "\t" + "Not Vaccinated" 
                   + "\t" + "NA" + "\t" + "NA" + "\t" + "Not Done" + "\t" + "NA" + "\t" + "Not Done" + "\t" + "NA" + "\t" + username + "\t" + password + "\n");
           
           
           patientfile.close();
           
           System.out.println("Successfully Registered");
           
        } catch (IOException e) {
            
            System.out.println("An Error has occured");
            
            e.printStackTrace();
        }
        
        
    }
    

    @Override
    public boolean verify(String username, String password) {
        
        //
        try  {
            
            File patientfile = new File("src/txt/patientdata.txt");
            FileReader fr = new FileReader(patientfile);
            BufferedReader br = new BufferedReader(fr);
            String line;
            
            while((line=br.readLine()) != null) {
                
                
                String[] brokenLine = line.split("\t");
             
                if(username.equals(brokenLine[11]) == true && password.equals(brokenLine[12]) == true) {
                    
                    
                    return true;
                    
                }
            }
            fr.close();
            
        } catch (IOException e) {
            
            System.out.println("An Error has occured");
            
            e.printStackTrace();
        }
        return false;
    }
    
    // To give the SAME object to other classes 
    public String patientBookmark(String username, String password) {
        
        try  {
            
            File patientfile = new File("src/txt/patientdata.txt");
            FileReader fr = new FileReader(patientfile);
            BufferedReader br = new BufferedReader(fr);
            String line;
            
            while((line=br.readLine()) != null) {
                
                
                String[] brokenLine = line.split("\t");
             
                if(username.equals(brokenLine[11]) == true && password.equals(brokenLine[12]) == true) {
                    
                    String patientIDo = brokenLine[0];
                    
                    return patientIDo;
                }
            }
            fr.close();
            
        } catch (IOException e) {
            
            System.out.println("An Error has occured");
            
            e.printStackTrace();
        }
        
        return "ID not found";
    }
    
    // using the patient id we can get all the data of the specific patient
    public String[] findLine(String patientID) {
        
        String[] notwork = new String[3];
        
        try  {
            
            File patientfile = new File("src/txt/patientdata.txt");
            FileReader fr = new FileReader(patientfile);
            BufferedReader br = new BufferedReader(fr);
            String line;
            
            while((line=br.readLine()) != null) {
                
                
                String[] brokenLine = line.split("\t");
             
                if(patientID.equals(brokenLine[0]) == true) {
                   
                    
                    return brokenLine;
                    
                }
            }
            fr.close();
            
        } catch (IOException e) {
            
            System.out.println("An Error has occured");
            
            e.printStackTrace();
        }
        
        return notwork;
        
    }
    
    
    public void editAccount(String patientID, String fullName, String age, String citizenship, String username, String password, String restData) {
        
        
        try  {
            
            File patientfile = new File("src/txt/patientdata.txt");
            FileReader fr = new FileReader(patientfile);
            BufferedReader br = new BufferedReader(fr);
            String line;
            
            StringBuilder newFileContents = new StringBuilder();
            
            
            while((line=br.readLine()) != null) {
                
                
                String[] brokenLine = line.split("\t");
             
                if(patientID.equals(brokenLine[0]) == true) {
                    
                    String newLine = patientID + "\t" + citizenship + "\t" + fullName + "\t" + age + "\t" + restData + "\t" + username + "\t" + password;
                    
                    newFileContents.append(newLine);
                    newFileContents.append("\n");
                    
                    
                    System.out.println(newLine);
                    
                } else {
                    
                    newFileContents.append(line);
                    newFileContents.append("\n");
                    
                    
                }
                
            }
            fr.close();
            
            FileWriter newPatientFile = new FileWriter("src/txt/patientdata.txt");
            BufferedWriter output = new BufferedWriter(newPatientFile);
            
            System.out.println(newFileContents);
            

            
            output.write(newFileContents.toString());
            
            output.close();
            
            
            
        } catch (IOException e) {
            
            System.out.println("An Error has occured");
            
            e.printStackTrace();
        }
        
            
            
            
    }
    
    public void getVac(String[] Fullline, String vaccine, String vacloc, int vacDos) {
        
        try  {
            
            File patientfile = new File("src/txt/patientdata.txt");
            FileReader fr = new FileReader(patientfile);
            BufferedReader br = new BufferedReader(fr);
            String line;
            
            StringBuilder newFileContents = new StringBuilder();
            
            
            while((line=br.readLine()) != null) {
                
                
                String[] brokenLine = line.split("\t");
             
                if(patientID.equals(brokenLine[0]) == true) {
                    
                    if(vacDos == 2) {
                    
                    String newLine = Fullline[0] + "\t" + Fullline[1] + "\t" + Fullline[2] + "\t" + Fullline[3] + "\t" + Fullline[4] + "\t" + vaccine + "\t" + Fullline[6]
                            + "\t" + Fullline[7] + "\t" + Fullline[8] + "\t" + Fullline[9] + "\t" + vacloc + "\t" + Fullline[11] + "\t" + Fullline[12];
                    
                    newFileContents.append(newLine);
                    newFileContents.append("\n");
                    
                    
                    System.out.println(newLine);
                    
                    } else {
                        
                        String newLine = Fullline[0] + "\t" + Fullline[1] + "\t" + Fullline[2] + "\t" + Fullline[3] + "\t" + Fullline[4] + "\t" + vaccine + "\t" + Fullline[6]
                            + "\t" + Fullline[7] + "\t" + "Not Applicable" + "\t" + "Not Applicable" + "\t" + vacloc + "\t" + Fullline[11] + "\t" + Fullline[12];
                    
                        newFileContents.append(newLine);
                        newFileContents.append("\n");
                    
                    
                        System.out.println(newLine);
                        
                        
                    }
                    
                } else {
                    
                    newFileContents.append(line);
                    newFileContents.append("\n");
                    
                    
                }
                
            }
            fr.close();
            
            FileWriter newPatientFile = new FileWriter("src/txt/patientdata.txt");
            BufferedWriter output = new BufferedWriter(newPatientFile);
            
            System.out.println(newFileContents);
            

            
            output.write(newFileContents.toString());
            
            output.close();
            
            
            
        } catch (IOException e) {
            
            System.out.println("An Error has occured");
            
            e.printStackTrace();
        }
        
        
        
    }
    
    
    
    
}
