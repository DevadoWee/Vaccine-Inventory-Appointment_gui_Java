/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author David
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.util.Scanner;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileWriter;
import java.io.PrintWriter;
import entities.userLogin;

public class PersonnelLogin extends userLogin{

    //same as other verify matching element after splitting line from file.
    //login purposes
    
    @Override
    public boolean verify(String username, String password) {
        try  {
            
            File PersonnelFile = new File("src/txt/PersonnelData.txt");
            FileReader fr = new FileReader(PersonnelFile);
            BufferedReader br = new BufferedReader(fr);
            String line;
            int found = 0;

            while((line=br.readLine()) != null) {
                String[] brokenLine = line.split("\t");              
                if(username.equals(brokenLine[1]) == true && password.equals(brokenLine[4]) == true) {
                    userLogin ul = new userLogin();
                    ul.loginActivity(username);
                    found += 1;
                    fr.close();
                    return true;
                }
                
            }
            fr.close();
            if (found == 0){
                System.out.println("Username or Password is incorrect.\nPlease try again.\t");
            }
            
        } catch (IOException e) {
            
            System.out.println("An Error has occured");
        } 
        return false;
    }
}