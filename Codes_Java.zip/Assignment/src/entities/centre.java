/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

/**
 *
 * @author user
 */
public class centre {

    
    public centre() {
    }
    
    
    
    private String cenID, cenName, vacID, vacCenStock;

    public String getCenID() {
        return cenID;
    }

    public void setCenID(String cenID) {
        this.cenID = cenID;
    }

    public String getCenName() {
        return cenName;
    }

    public void setCenName(String cenName) {
        this.cenName = cenName;
    }

    public String getVacID() {
        return vacID;
    }

    public void setVacID(String vacID) {
        this.vacID = vacID;
    }

    public String getVacCenStock() {
        return vacCenStock;
    }

    public void setVacCenStock(String vacCenStock) {
        this.vacCenStock = vacCenStock;
    }
    
    
    public void addVaccineProgram() {
        
        //String cenID, String cenName, String vacName, String vacQuan
        try {
            
           FileWriter vaccinefile = new FileWriter("src/txt/centredata.txt", true);
           

           vaccinefile.write("BJ" + "\t" + "Bukit Jalil" + "\t" + "PF" + "\t" + "20000" + "\n");
           vaccinefile.write("HKL" + "\t" + "Hospital Kuala Lumpur" + "\t" + "PF" + "\t" + "10000" + "\n");
           vaccinefile.write("BJ" + "\t" + "Bukit Jalil" + "\t" + "CS" + "\t" + "10000" + "\n");
           
           vaccinefile.close();
           
           System.out.println("Successfully Registered");
           
        } catch (IOException e) {
            
            System.out.println("An Error has occured");
            
            e.printStackTrace();
        }
        
        
    }
    
    public String vaccineFilter() {
        
        
        
        try  {
            
            File centrefile = new File("src/txt/centredata.txt");
            FileReader fr = new FileReader(centrefile);
            BufferedReader br = new BufferedReader(fr);
            String line;
            
            
            int i = 0;
            String arrayNest = "";
            
            while((line=br.readLine()) != null) {
                
                String[] brokenLine = line.split("\t");
                
                arrayNest += Arrays.toString(brokenLine);
                arrayNest += ";";
                i++;
                
                //System.out.println(Arrays.toString(brokenLine));
                //System.out.println(arrayNest);
                
                
                
            }
            
        return arrayNest;

            
            
        } catch (IOException e) {
            
            System.out.println("An Error has occured");
            
            e.printStackTrace();
        }
        
       return null;
        
        
    }
    
    
    public boolean vaccineApplication(String vacID, String cenID) {
        
        
        try  {
            
            File centrefile = new File("src/txt/centredata.txt");
            FileReader fr = new FileReader(centrefile);
            BufferedReader br = new BufferedReader(fr);
            String line;
            
            StringBuilder newFileContents = new StringBuilder();
            
            int flag = 0;
            
            while((line=br.readLine()) != null) {
                
                String[] brokenLine = line.split("\t");
                
                if(cenID.equals(brokenLine[0]) && vacID.equals(brokenLine[2])) {
                    
                    //System.out.println(brokenLine); 
                    int vacstok = Integer.parseInt(brokenLine[3]);
                    
                    if(vacstok > 0) {
                        
                        // To minus vaccine stock but number of vaccine dosage so its already booked for that person
                        vaccine vac = new vaccine();
                        int numDos = vac.getDosage(vacID);
                        
                        vacstok = vacstok - numDos;
                        
                        String vacstokStr = Integer.toString(vacstok);
                        
                        String newLine = brokenLine[0] + "\t" + brokenLine[1] + "\t" + brokenLine[2] + "\t" + vacstokStr;
                        
                        newFileContents.append(newLine);
                        newFileContents.append("\n");
                        
                        System.out.println(newLine);
                        
                        flag = 1;
                        
                        

                        
                    } else {
                        
                        if(flag == 0) {
                            flag = 3; // No vaccine stock
                        }
                    }
                    
                } else {
                    
                    
                    newFileContents.append(line);
                    newFileContents.append("\n");
                    
                    if(flag == 0) {
                        flag = 2; // Centre does not have that vaccine
                    }
                }
                
            }
            
            FileWriter newCentreFile = new FileWriter("src/txt/centredata.txt");
            BufferedWriter output = new BufferedWriter(newCentreFile);
            
            switch(flag) {
                
                case 1: fr.close();
                        System.out.println("Case 1");
                        output.write(newFileContents.toString());
            
                        output.close();
                        
                        return true;
                   
                case 2: fr.close();
                
                        System.out.println("Case 2");
                        output.write(newFileContents.toString());
                        
                        output.close();
                        return false;
                
                case 3: fr.close();
                
                        System.out.println("Case 3");
                        output.write(newFileContents.toString());
                        
                        output.close();
                        return false;
                
            }
            
            
        } catch (IOException e) {
            
            System.out.println("An Error has occured");
            
            e.printStackTrace();
        }
        
        
        
        
        
        
        
        return false;
    }
    
    public String getCenNameFull(String CenIDs) {
        
        try  {
            
            File centrefile = new File("src/txt/centredata.txt");
            FileReader fr = new FileReader(centrefile);
            BufferedReader br = new BufferedReader(fr);
            String line;
            
            while((line=br.readLine()) != null) {
                
                
                String[] brokenLine = line.split("\t");
             
                if(CenIDs.equals(brokenLine[0]) == true) {
                    
                    String centreIDo = brokenLine[1];
                    
                    return centreIDo;
                }
            }
            fr.close();
            
        } catch (IOException e) {
            
            System.out.println("An Error has occured");
            
            e.printStackTrace();
        }
        
        return "forgot";
    }
    
    
    
    
}
