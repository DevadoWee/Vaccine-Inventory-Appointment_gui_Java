/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

import gui.startupmenu;
import entities.ManageVaccine;//to be deleted
import entities.centre; // to be deleted
import entities.PersonnelLogin;//to be deleted
import entities.ManagePeople;//to be deleted
/**
 *
 * @author user
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // TODO code application logic here
        
//        centre cen = new centre();
//        cen.addVaccineProgram();

        //ManageVaccine pr = new ManageVaccine();
        //pr.AddVaccine("HKL", "PF", 5200);
        //pr.RemoveVaccine("BJ", "PF", 90);
        //pr.ModifyVaccine("HKL","PF", 2001);
        //pr.ViewVaccine();
        //pr.SearchVaccine("HKL");
        
        //PersonnelLogin pl = new PersonnelLogin();
        //pl.PersonnelVerify("Michelle Obama", "hola");

        startupmenu startup = new startupmenu();
        startup.setVisible(true);
        
        


        
        
    }
}
